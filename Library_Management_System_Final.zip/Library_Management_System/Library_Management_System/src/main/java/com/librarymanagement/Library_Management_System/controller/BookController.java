package com.librarymanagement.Library_Management_System.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.librarymanagement.Library_Management_System.entity.Book;
import com.librarymanagement.Library_Management_System.entity.Category;
import com.librarymanagement.Library_Management_System.service.BookService;
import com.librarymanagement.Library_Management_System.service.CategoryService;
import com.librarymanagement.Library_Management_System.util.CategoryTree;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/books")
    public String getAllBooks(HttpServletRequest request, Model model) {
        Cookie[] cookies = request.getCookies();
        String userId = null;
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("userId".equals(cookie.getName())) {
                    userId = cookie.getValue();
                    break;
                }
            }
        }

        List<Book> books = bookService.getAllBooks();
        model.addAttribute("books", books);
        model.addAttribute("userId", userId);  
        return "books";
    }


    @GetMapping("/book/{id}")
    public String showBookDetails(@PathVariable("id") int id, Model model) {
        try {
            Book book = bookService.getBookById(id);
            int userId = 1;  
            model.addAttribute("book", book);
            model.addAttribute("userId", userId);  
            return "book-details"; 
        } catch (Exception e) {
            model.addAttribute("error", "Book not found: " + e.getMessage());
            return "error";
        }
    }

    @GetMapping("/books/search")
    public String searchBooksByCategory(@RequestParam("category") String categoryName, Model model) {
        try {
            List<Category> allCategories = categoryService.getAllCategories();
            CategoryTree categoryTree = new CategoryTree(allCategories);

            Category searchedCategory = allCategories.stream()
                    .filter(cat -> cat.getCategoryName().equalsIgnoreCase(categoryName))
                    .findFirst()
                    .orElse(null);

            if (searchedCategory == null) {
                model.addAttribute("error", "No category found with name: " + categoryName);
                model.addAttribute("books", new ArrayList<>()); // Pass empty list
                return "books";
            }

            List<Category> subtreeCategories = categoryTree.getSubtreeCategories(searchedCategory.getCategoryId());
            List<String> subtreeCategoryNames = new ArrayList<>();
            for (Category cat : subtreeCategories) {
                subtreeCategoryNames.add(cat.getCategoryName());
            }

            List<Book> books = bookService.getBooksByCategoryNames(subtreeCategoryNames);

            model.addAttribute("books", books);
            model.addAttribute("message", "Books in category: " + categoryName + " and its subcategories");
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while searching: " + e.getMessage());
            model.addAttribute("books", new ArrayList<>()); // Pass empty list
        }
        return "books";
    }

}
