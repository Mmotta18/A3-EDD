package com.librarymanagement.Library_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.librarymanagement.Library_Management_System.entity.Book;
import com.librarymanagement.Library_Management_System.service.BookService;
import com.librarymanagement.Library_Management_System.service.CategoryService;
import com.librarymanagement.Library_Management_System.service.LoanService;

@Controller
@RequestMapping("/adminbooks")
public class AdminController {

    @Autowired
    private BookService bookService;
    @Autowired
    private LoanService loanService;
    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public String showAllBooks(Model model) {
        try {
            model.addAttribute("books", bookService.getAllBooks());  
            return "adminbooks";  
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while fetching books: " + e.getMessage());
            return "error"; 
        }
    }

    @PostMapping("/update-availability/{bookId}/{availability}")
    public String updateBookAvailability(@PathVariable("bookId") int bookId,
      @PathVariable("availability") int availability) {
        try {
            Book book = bookService.getBookById(bookId);
            if (book != null) {
                book.setAvailability(availability);
                bookService.saveBook(book);  
                return "redirect:/adminbooks";  
            } else {
                return "error";  
            }
        } catch (Exception e) {
            return "error";  
        }
    }

    @PostMapping("/delete/{bookId}")
    public String deleteBook(@PathVariable("bookId") int bookId) {
        try {
            System.out.println("Deleting book with ID: " + bookId);
            bookService.deleteBookById(bookId);  
            return "redirect:/adminbooks";  
        } catch (Exception e) {
            e.printStackTrace();  
            return "error";  
        }
    }
    // Display the Add Book Form
    @GetMapping("/add")
    public String showAddBookForm(Model model) {
        model.addAttribute("categories", categoryService.getAllCategories());  
        return "add-book";  
    }

    @PostMapping("/add")
    public String addBook(@ModelAttribute Book book, Model model) {
        try {
            bookService.saveBook(book);  
            model.addAttribute("message", "Book added successfully!");  
            return "redirect:/adminbooks";  
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while adding the book: " + e.getMessage());  
            return "add-book";  
        }
    }

}

