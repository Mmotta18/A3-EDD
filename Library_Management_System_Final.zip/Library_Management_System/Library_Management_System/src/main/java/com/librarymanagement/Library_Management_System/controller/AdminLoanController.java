package com.librarymanagement.Library_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.librarymanagement.Library_Management_System.entity.Loan;
import com.librarymanagement.Library_Management_System.service.LoanService;

@Controller
@RequestMapping("/admin/loans")
public class AdminLoanController {

    @Autowired
    private LoanService loanService;

    @GetMapping
    public String showNextLoan(Model model) {
        loanService.loadPendingLoans();  
        Loan nextLoan = loanService.getNextLoanToApprove();
        if (nextLoan != null) {
            model.addAttribute("loan", nextLoan);
            return "approve-loan";  
        } else {
            model.addAttribute("message", "No pending loans.");
            return "no-loans";  
        }
    }

    
    @PostMapping("/approve/{loanId}")
    public String approveLoan(@PathVariable int loanId) {
        loanService.approveLoan(loanId);
        return "redirect:/admin/loans"; 
    }
}
