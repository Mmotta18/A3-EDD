package com.librarymanagement.Library_Management_System.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.librarymanagement.Library_Management_System.entity.Book;
import com.librarymanagement.Library_Management_System.repository.BookRepository;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    
    public Book getBookById(int bookId) {
        Optional<Book> book = bookRepository.findById(bookId);
        return book.orElse(null); 
    }
    public List<Book> getBooksByCategoryNames(List<String> categoryNames) {
        return bookRepository.findByCategoryIn(categoryNames);
    }
    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    public void deleteBookById(int bookId) {
        Optional<Book> book = bookRepository.findById(bookId);
        if (book.isPresent()) {
            bookRepository.deleteById(bookId);
        }
    }

}
