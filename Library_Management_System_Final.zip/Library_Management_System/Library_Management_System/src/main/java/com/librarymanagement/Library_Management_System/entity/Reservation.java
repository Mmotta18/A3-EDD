package com.librarymanagement.Library_Management_System.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Reservation {

    @Id  
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private int reservationId;

    @Column(name = "book_id")  
    private int bookId;

    @Column(name = "user_id")  
    private int userId;

    @Column(name = "reservation_date")  
    private LocalDateTime reservationDate;

    public Reservation() {}

    public Reservation(int bookId, int userId, LocalDateTime reservationDate) {
        this.bookId = bookId;
        this.userId = userId;
        this.reservationDate = reservationDate;
    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public LocalDateTime getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDateTime reservationDate) {
        this.reservationDate = reservationDate;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "reservationId=" + reservationId +
                ", bookId=" + bookId +
                ", userId=" + userId +
                ", reservationDate=" + reservationDate +
                '}';
    }
}
