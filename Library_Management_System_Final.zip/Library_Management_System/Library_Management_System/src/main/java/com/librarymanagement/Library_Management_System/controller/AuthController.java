package com.librarymanagement.Library_Management_System.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class AuthController {

    @GetMapping("/logout")
    public String logout(HttpServletResponse response) {
        // Remove the userId cookie by setting its max age to 0
        Cookie userIdCookie = new Cookie("userId", "");
        userIdCookie.setMaxAge(0);
        userIdCookie.setPath("/");  
        response.addCookie(userIdCookie);

        return "redirect:/";  
    }
}
