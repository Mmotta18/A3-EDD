package com.librarymanagement.Library_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.librarymanagement.Library_Management_System.entity.Category;
import com.librarymanagement.Library_Management_System.service.CategoryService;

@Controller
@RequestMapping("/admin/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/add")
    public String showAddCategoryForm(Model model) {
        model.addAttribute("categories", categoryService.getAllCategories()); 
        model.addAttribute("category", new Category()); 
        return "add-category"; 
    }

    @PostMapping("/add")
    public String addCategory(Category category, Model model) {
        try {
            categoryService.saveCategory(category); 
            model.addAttribute("message", "Category added successfully!");
            return "redirect:/admin/categories/add"; 
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while adding the category.");
            return "add-category"; 
        }
    }
}
