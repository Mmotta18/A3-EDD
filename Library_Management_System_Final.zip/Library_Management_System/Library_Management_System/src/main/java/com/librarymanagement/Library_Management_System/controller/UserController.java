package com.librarymanagement.Library_Management_System.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.librarymanagement.Library_Management_System.entity.User;
import com.librarymanagement.Library_Management_System.service.UserService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @GetMapping("/signup")
    public String showSignupForm() {
        return "signup"; 
    }

    @PostMapping("/signup")
    public String registerUser(@RequestParam String name,
                               @RequestParam String email,
                               @RequestParam String password,
                               @RequestParam String userType,
                               Model model,
                               HttpServletResponse response) {
        try {
            User newUser = new User(name, email, userType, password);
            User savedUser = userService.addUser(newUser);

            if (savedUser != null) {
                Cookie userIdCookie = new Cookie("userId", String.valueOf(savedUser.getUserId()));
                userIdCookie.setHttpOnly(true);
                userIdCookie.setPath("/");
                response.addCookie(userIdCookie);

                if ("admin".equalsIgnoreCase(userType)) {
                    model.addAttribute("message", "Admin registration successful!");
                    logger.info("Admin registration successful for: {}", name);
                    return "redirect:/adminbooks"; 
                } else {
                    model.addAttribute("message", "Registration successful!");
                    logger.info("User registration successful for: {}", name);
                    return "redirect:/books"; 
                }
            } else {
                model.addAttribute("error", "User could not be saved.");
                logger.error("User registration failed for: {}", name);
            }

            return "signup";        } catch (Exception e) {
            model.addAttribute("error", "An error occurred during registration: " + e.getMessage());
            logger.error("An error occurred during user registration: {}", e.getMessage(), e);
            return "signup"; 
        }
    }


    @GetMapping("/login")
    public String showLoginForm() {
        return "login"; 
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            Model model,
                            HttpServletResponse response) {
        try {
            User user = userService.findByEmail(email);

            if (user != null && user.getPassword().equals(password)) {
                Cookie userIdCookie = new Cookie("userId", String.valueOf(user.getUserId()));
                userIdCookie.setHttpOnly(true);
                userIdCookie.setPath("/");
                response.addCookie(userIdCookie);

                if ("admin".equalsIgnoreCase(user.getUserType())) {
                    model.addAttribute("message", "Admin login successful!");
                    logger.info("Admin login successful for: {}", email);
                    return "redirect:/adminbooks"; 
                } else {
                    model.addAttribute("message", "Login successful!");
                    logger.info("User login successful for: {}", email);
                    return "redirect:/books"; 
                }
            } else {
                model.addAttribute("error", "Invalid email or password.");
                logger.error("Login failed for: {}", email);
                return "login"; 
            }
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred during login: " + e.getMessage());
            logger.error("An error occurred during user login: {}", e.getMessage(), e);
            return "login"; 
        }
    }


    @GetMapping("/users")
    public String showAllUsers(Model model) {
        try {
            List<User> users = userService.getAllUsers(); 
            model.addAttribute("users", users);
            return "users"; 
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while fetching users: " + e.getMessage());
            logger.error("An error occurred while fetching users: {}", e.getMessage(), e);
            return "error"; 
        }
    }
}
