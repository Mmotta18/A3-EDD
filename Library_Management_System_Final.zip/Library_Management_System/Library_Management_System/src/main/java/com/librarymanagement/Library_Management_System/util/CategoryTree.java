package com.librarymanagement.Library_Management_System.util;

import java.util.ArrayList;
import java.util.List;

import com.librarymanagement.Library_Management_System.entity.Category;

public class CategoryTree {

    private List<CategoryNode> rootCategories;

    public CategoryTree(List<Category> allCategories) {
        this.rootCategories = buildTree(allCategories);
    }

    private List<CategoryNode> buildTree(List<Category> allCategories) {
        List<CategoryNode> rootNodes = new ArrayList<>();

        for (Category category : allCategories) {
            CategoryNode node = new CategoryNode(category);
            if (category.getParentCategory() == null) {
                rootNodes.add(node); 
            } else {
                for (CategoryNode parentNode : rootNodes) {
                    if (parentNode.getCategory().getCategoryId() == category.getParentCategory().getCategoryId()) {
                        parentNode.addChild(node);
                        break;
                    }
                }
            }
        }
        return rootNodes;
    }

    public List<CategoryNode> getRootCategories() {
        return rootCategories;
    }

    public List<Category> getSubtreeCategories(int categoryId) {
        List<Category> result = new ArrayList<>();

        CategoryNode categoryNode = findCategoryNodeById(categoryId);

        if (categoryNode != null) {
            collectSubtreeCategories(categoryNode, result);
        }

        return result;
    }

    private void collectSubtreeCategories(CategoryNode node, List<Category> result) {
        if (node == null) {
            return;
        }

        result.add(node.getCategory());

        for (CategoryNode childNode : node.getChildren()) {
            collectSubtreeCategories(childNode, result);
        }
    }

    private CategoryNode findCategoryNodeById(int categoryId) {
        for (CategoryNode rootCategoryNode : rootCategories) {
            CategoryNode foundNode = findCategoryNodeInSubtree(rootCategoryNode, categoryId);
            if (foundNode != null) {
                return foundNode;
            }
        }
        return null;  
    }

    private CategoryNode findCategoryNodeInSubtree(CategoryNode node, int categoryId) {
        if (node == null) {
            return null;
        }

        if (node.getCategory().getCategoryId() == categoryId) {
            return node;
        }

        for (CategoryNode childNode : node.getChildren()) {
            CategoryNode foundNode = findCategoryNodeInSubtree(childNode, categoryId);
            if (foundNode != null) {
                return foundNode;
            }
        }
        return null;  
    }

    public static class CategoryNode {
        private Category category;
        private List<CategoryNode> children;

        public CategoryNode(Category category) {
            this.category = category;
            this.children = new ArrayList<>();
        }

        public void addChild(CategoryNode child) {
            this.children.add(child);
        }

        public Category getCategory() {
            return category;
        }

        public List<CategoryNode> getChildren() {
            return children;
        }
    }
}
