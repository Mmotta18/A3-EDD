package com.librarymanagement.Library_Management_System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.librarymanagement.Library_Management_System.entity.Loan;
import com.librarymanagement.Library_Management_System.service.LoanService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class LoanController {

    @Autowired
    private LoanService loanService;

    @GetMapping("/loan-history/{userId}")
    public String getLoanHistory(@PathVariable("userId") int userId, Model model) {
        List<Loan> loans = loanService.getLoanHistoryByUserId(userId);
        model.addAttribute("userId", userId);
        model.addAttribute("loans", loans);
        return "loan-history";  
    }

    @PostMapping("/return-book/{loanId}")
    public String returnBook(@PathVariable("loanId") int loanId, Model model) {
        try {
            Loan loan = loanService.getLoanById(loanId);
            int userId = loan.getUserId();  

            loanService.deleteLoanById(loanId);

            model.addAttribute("message", "Book returned successfully.");

            return "redirect:/loan-history/" + userId;  
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while returning the book: " + e.getMessage());
            return "loan-history";  
        }
    }
    @PostMapping("/request-loan")
    public String requestLoan(@RequestParam("bookId") int bookId, HttpServletRequest request, Model model) {
        try {
            Cookie[] cookies = request.getCookies();
            int userId = -1;
            for (Cookie cookie : cookies) {
                if ("userId".equals(cookie.getName())) {
                    userId = Integer.parseInt(cookie.getValue());
                    break;
                }
            }

            if (userId == -1) {
                model.addAttribute("error", "User ID is not available in cookies.");
                return "error";  
            }

            loanService.requestLoan(bookId, userId);
            model.addAttribute("message", "Loan request successful.");
            return "redirect:/loan-history/" + userId;  
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while requesting the loan: " + e.getMessage());
            return "error";          }
    }
}
