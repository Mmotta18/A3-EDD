package com.librarymanagement.Library_Management_System.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.librarymanagement.Library_Management_System.entity.Loan;
import com.librarymanagement.Library_Management_System.repository.LoanRepository;
import com.librarymanagement.Library_Management_System.util.QueueUtil;

@Service
public class LoanService {

    @Autowired
    private LoanRepository loanRepository;

    public Loan saveLoan(Loan loan) {
        return loanRepository.save(loan);  
    }

    public List<Loan> getLoanHistoryByUserId(int userId) {
        return loanRepository.findByUserId(userId);
    }

    public void deleteLoanById(int loanId) {
        loanRepository.deleteById(loanId);
    }

    public Loan getLoanById(int loanId) {
        return loanRepository.findById(loanId).orElseThrow(() -> new IllegalArgumentException("Loan not found with ID: " + loanId));
    }
    public void requestLoan(int bookId, int userId) {
        Loan loan = new Loan();
        loan.setBookId(bookId);
        loan.setUserId(userId);
        loan.setLoanDate(LocalDate.now());
        loanRepository.save(loan);
    }

    private QueueUtil<Loan> loanQueue = new QueueUtil<>();

    public void loadPendingLoans() {
        while (!loanQueue.isEmpty()) {
            loanQueue.dequeue();
        }

        List<Loan> pendingLoans = loanRepository.findByApproved(false);
        pendingLoans.sort((loan1, loan2) -> Integer.compare(loan1.getLoanId(), loan2.getLoanId()));

        for (Loan loan : pendingLoans) {
            loanQueue.enqueue(loan);
        }
    }

    public Loan getNextLoanToApprove() {
        return loanQueue.isEmpty() ? null : loanQueue.peek();
    }

    public void approveLoan(int loanId) {
        Loan loan = loanRepository.findById(loanId).orElseThrow(() -> new RuntimeException("Loan not found"));
        loan.setApproved(true);
        loanRepository.save(loan);
        loanQueue.dequeue();
    }
}
