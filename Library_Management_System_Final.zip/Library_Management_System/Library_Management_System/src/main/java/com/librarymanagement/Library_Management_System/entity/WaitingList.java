package com.librarymanagement.Library_Management_System.entity;

import com.librarymanagement.Library_Management_System.util.QueueUtil;

public class WaitingList {
    private int bookId;
    private QueueUtil<Integer> userQueue; 

    public WaitingList(int bookId) {
        this.bookId = bookId;
        this.userQueue = new QueueUtil<>();
    }

    public void addUserToWaitingList(int userId) {
        userQueue.enqueue(userId);
    }

    public int getNextUser() {
        return userQueue.dequeue();
    }

    public boolean isEmpty() {
        return userQueue.isEmpty();
    }

    public int size() {
        return userQueue.size();
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }
}
