package com.librarymanagement.Library_Management_System.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.librarymanagement.Library_Management_System.entity.Category;
import com.librarymanagement.Library_Management_System.repository.CategoryRepository;
import com.librarymanagement.Library_Management_System.util.CategoryTree;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

   
    public Category saveCategory(Category category) {
        return categoryRepository.save(category);  
    }

    public Optional<Category> getCategoryById(int categoryId) {
        return categoryRepository.findById(categoryId); 
    }

    public List<Category> getAllCategories() {
        return categoryRepository.findAll();  
    }
    
    public List<Category> getSubCategories(int parentCategoryId) {
        List<Category> allCategories = categoryRepository.findAll();
        CategoryTree categoryTree = new CategoryTree(allCategories); 

        List<Category> subcategories = categoryTree.getSubtreeCategories(parentCategoryId);
        return subcategories;
    }

    public void deleteCategoryById(int categoryId) {
        categoryRepository.deleteById(categoryId);  
    }
}
