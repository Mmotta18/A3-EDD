package com.librarymanagement.Library_Management_System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.librarymanagement.Library_Management_System.entity.User;
import com.librarymanagement.Library_Management_System.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User addUser(User user) {
        try {
            if (userRepository.findByEmail(user.getEmail()) != null) {
                throw new IllegalArgumentException("Email is already in use.");
            }
            return userRepository.save(user);
        } catch (Exception e) {
            throw new RuntimeException("An error occurred while adding the user.", e);
        }
    }

    public List<User> getAllUsers() {
        return userRepository.findAll(); 
    }
    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}
