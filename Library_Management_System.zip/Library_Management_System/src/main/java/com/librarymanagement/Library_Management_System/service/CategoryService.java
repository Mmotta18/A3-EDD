package com.librarymanagement.Library_Management_System.service;

import com.librarymanagement.Library_Management_System.entity.Category;
import com.librarymanagement.Library_Management_System.repository.CategoryRepository;
import com.librarymanagement.Library_Management_System.util.CategoryTree;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    // Save a category (either a parent or sub-category)
    public Category saveCategory(Category category) {
        return categoryRepository.save(category);  // Save the category to the database
    }

    // Find a category by its ID
    public Optional<Category> getCategoryById(int categoryId) {
        return categoryRepository.findById(categoryId);  // Return the category or empty if not found
    }

    // Method to get all categories
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();  // Assuming this returns all categories from the database
    }
    
    // Get the category tree and find all subcategories of a given category
    public List<Category> getSubCategories(int parentCategoryId) {
        List<Category> allCategories = categoryRepository.findAll();
        CategoryTree categoryTree = new CategoryTree(allCategories); // Build the tree

        // Get the subcategories in the subtree of the given parent category
        List<Category> subcategories = categoryTree.getSubtreeCategories(parentCategoryId);
        return subcategories;
    }

    // Delete a category by its ID
    public void deleteCategoryById(int categoryId) {
        categoryRepository.deleteById(categoryId);  // Delete the category from the database
    }
}
