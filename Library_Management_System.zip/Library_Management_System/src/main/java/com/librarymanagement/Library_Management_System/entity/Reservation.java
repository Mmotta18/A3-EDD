package com.librarymanagement.Library_Management_System.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import java.time.LocalDateTime;

@Entity
public class Reservation {

    @Id  // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-generate the primary key
    private int reservationId;

    @Column(name = "book_id")  // Maps to the 'book_id' field in the database
    private int bookId;

    @Column(name = "user_id")  // Maps to the 'user_id' field in the database
    private int userId;

    @Column(name = "reservation_date")  // Maps to the 'reservation_date' field in the database
    private LocalDateTime reservationDate;

    // Default constructor
    public Reservation() {}

    // Parameterized constructor
    public Reservation(int bookId, int userId, LocalDateTime reservationDate) {
        this.bookId = bookId;
        this.userId = userId;
        this.reservationDate = reservationDate;
    }

    // Getters and Setters
    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public LocalDateTime getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDateTime reservationDate) {
        this.reservationDate = reservationDate;
    }

    // ToString method for debugging
    @Override
    public String toString() {
        return "Reservation{" +
                "reservationId=" + reservationId +
                ", bookId=" + bookId +
                ", userId=" + userId +
                ", reservationDate=" + reservationDate +
                '}';
    }
}
