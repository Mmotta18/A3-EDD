package com.librarymanagement.Library_Management_System.util;


import java.util.EmptyStackException;

public class StackUtil<T> {
    private Node<T> top;
    private int size;

    // Node class for stack elements
    private static class Node<T> {
        private T data;
        private Node<T> next;

        public Node(T data) {
            this.data = data;
        }
    }

    // Push element onto stack
    public void push(T item) {
        Node<T> newNode = new Node<>(item);
        newNode.next = top;
        top = newNode;
        size++;
    }

    // Pop element from stack
    public T pop() {
        if (isEmpty()) throw new EmptyStackException();
        T item = top.data;
        top = top.next;
        size--;
        return item;
    }

    // Peek top element without removing
    public T peek() {
        if (isEmpty()) throw new EmptyStackException();
        return top.data;
    }

    // Check if stack is empty
    public boolean isEmpty() {
        return top == null;
    }

    // Get stack size
    public int size() {
        return size;
    }
}
