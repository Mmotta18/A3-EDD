package com.librarymanagement.Library_Management_System.service;

import com.librarymanagement.Library_Management_System.entity.Loan;
import com.librarymanagement.Library_Management_System.repository.LoanRepository;
import com.librarymanagement.Library_Management_System.util.QueueUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class LoanService {

    @Autowired
    private LoanRepository loanRepository;

    // Method to save a loan request
    public Loan saveLoan(Loan loan) {
        return loanRepository.save(loan);  // Save loan to database
    }

    // Method to get loan history by user ID
    public List<Loan> getLoanHistoryByUserId(int userId) {
        // Retrieve loans for the given user ID from the database
        return loanRepository.findByUserId(userId);
    }

    // Method to delete a loan entry by its ID
    public void deleteLoanById(int loanId) {
        loanRepository.deleteById(loanId);
    }

    // Method to get a loan by its ID (returns Optional)
    public Loan getLoanById(int loanId) {
        // Return loan or throw exception if not found
        return loanRepository.findById(loanId).orElseThrow(() -> new IllegalArgumentException("Loan not found with ID: " + loanId));
    }
    // Request a loan for a book
    public void requestLoan(int bookId, int userId) {
        // Logic for requesting a loan, e.g., create a new loan record in the database
        Loan loan = new Loan();
        loan.setBookId(bookId);
        loan.setUserId(userId);
        loan.setLoanDate(LocalDate.now());
        loanRepository.save(loan);
    }

    private QueueUtil<Loan> loanQueue = new QueueUtil<>();

    // Load non-approved loans into the queue, sorted by loanId
    public void loadPendingLoans() {
        // Clear the queue first
        while (!loanQueue.isEmpty()) {
            loanQueue.dequeue();
        }

        // Get non-approved loans and sort by loanId
        List<Loan> pendingLoans = loanRepository.findByApproved(false);
        pendingLoans.sort((loan1, loan2) -> Integer.compare(loan1.getLoanId(), loan2.getLoanId()));

        // Enqueue loans into the queue
        for (Loan loan : pendingLoans) {
            loanQueue.enqueue(loan);
        }
    }

    // Get the next loan in the queue for approval
    public Loan getNextLoanToApprove() {
        return loanQueue.isEmpty() ? null : loanQueue.peek();
    }

    // Approve the loan and remove it from the queue
    public void approveLoan(int loanId) {
        Loan loan = loanRepository.findById(loanId).orElseThrow(() -> new RuntimeException("Loan not found"));
        loan.setApproved(true);
        loanRepository.save(loan);
        loanQueue.dequeue(); // Remove the approved loan from the queue
    }
}
