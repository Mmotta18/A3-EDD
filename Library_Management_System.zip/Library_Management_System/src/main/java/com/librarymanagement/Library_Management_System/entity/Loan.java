package com.librarymanagement.Library_Management_System.entity;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.Date;

@Entity
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int loanId;

    @Column(name = "book_id")
    private int bookId;  // Store only the book ID

    @Column(name = "user_id")
    private int userId;  // Store only the user ID

    @Column(name = "loan_date")
    private LocalDate loanDate;

    @Column(name = "approved")
    private boolean approved;

    // Default constructor
    public Loan() {}

    // Parameterized constructor
    public Loan(int bookId, int userId, LocalDate loanDate, boolean approved) {
        this.bookId = bookId;
        this.userId = userId;
        this.loanDate = loanDate;
        this.approved = approved;
    }

    // Getters and Setters
    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public LocalDate getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(LocalDate loanDate) {
        this.loanDate = loanDate;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    // ToString method for debugging
    @Override
    public String toString() {
        return "Loan{" +
                "loanId=" + loanId +
                ", bookId=" + bookId +
                ", userId=" + userId +
                ", loanDate=" + loanDate +
                ", approved=" + approved +
                '}';
    }
}
