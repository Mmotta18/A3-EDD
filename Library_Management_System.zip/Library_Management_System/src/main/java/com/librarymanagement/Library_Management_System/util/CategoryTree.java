package com.librarymanagement.Library_Management_System.util;

import com.librarymanagement.Library_Management_System.entity.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryTree {

    private List<CategoryNode> rootCategories;

    public CategoryTree(List<Category> allCategories) {
        this.rootCategories = buildTree(allCategories);
    }

    // Build the tree structure
    private List<CategoryNode> buildTree(List<Category> allCategories) {
        List<CategoryNode> rootNodes = new ArrayList<>();

        // Create a map to store the CategoryNode objects for fast lookup by category ID
        for (Category category : allCategories) {
            CategoryNode node = new CategoryNode(category);
            if (category.getParentCategory() == null) {
                rootNodes.add(node); // Root categories don't have parents
            } else {
                // Find the parent node and add this category as a child
                for (CategoryNode parentNode : rootNodes) {
                    if (parentNode.getCategory().getCategoryId() == category.getParentCategory().getCategoryId()) {
                        parentNode.addChild(node);
                        break;
                    }
                }
            }
        }
        return rootNodes;
    }

    // Getter for root categories
    public List<CategoryNode> getRootCategories() {
        return rootCategories;
    }

    // Function to get all categories within a subtree
    public List<Category> getSubtreeCategories(int categoryId) {
        List<Category> result = new ArrayList<>();

        // Find the category node with the given categoryId
        CategoryNode categoryNode = findCategoryNodeById(categoryId);

        // If the category node is found, collect all categories in its subtree
        if (categoryNode != null) {
            collectSubtreeCategories(categoryNode, result);
        }

        return result;
    }

    // Recursive function to collect categories in the subtree
    private void collectSubtreeCategories(CategoryNode node, List<Category> result) {
        if (node == null) {
            return;
        }

        // Add the current category to the result
        result.add(node.getCategory());

        // Recursively collect all child categories
        for (CategoryNode childNode : node.getChildren()) {
            collectSubtreeCategories(childNode, result);
        }
    }

    // Helper method to find a CategoryNode by its ID
    private CategoryNode findCategoryNodeById(int categoryId) {
        // Iterate through all root categories and search for the categoryId
        for (CategoryNode rootCategoryNode : rootCategories) {
            CategoryNode foundNode = findCategoryNodeInSubtree(rootCategoryNode, categoryId);
            if (foundNode != null) {
                return foundNode;
            }
        }
        return null;  // Return null if the category with categoryId is not found
    }

    // Recursive method to search for a CategoryNode in a subtree
    private CategoryNode findCategoryNodeInSubtree(CategoryNode node, int categoryId) {
        if (node == null) {
            return null;
        }

        if (node.getCategory().getCategoryId() == categoryId) {
            return node;
        }

        for (CategoryNode childNode : node.getChildren()) {
            CategoryNode foundNode = findCategoryNodeInSubtree(childNode, categoryId);
            if (foundNode != null) {
                return foundNode;
            }
        }
        return null;  // Return null if the categoryId is not found in the subtree
    }

    // Inner class to represent a category node in the tree
    public static class CategoryNode {
        private Category category;
        private List<CategoryNode> children;

        public CategoryNode(Category category) {
            this.category = category;
            this.children = new ArrayList<>();
        }

        public void addChild(CategoryNode child) {
            this.children.add(child);
        }

        public Category getCategory() {
            return category;
        }

        public List<CategoryNode> getChildren() {
            return children;
        }
    }
}
