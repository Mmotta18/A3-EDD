package com.librarymanagement.Library_Management_System.controller;

import com.librarymanagement.Library_Management_System.entity.Loan;
import com.librarymanagement.Library_Management_System.service.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/loans")
public class AdminLoanController {

    @Autowired
    private LoanService loanService;

    // Display the next loan to approve
    @GetMapping
    public String showNextLoan(Model model) {
        loanService.loadPendingLoans();  // Load pending loans into the queue
        Loan nextLoan = loanService.getNextLoanToApprove();
        if (nextLoan != null) {
            model.addAttribute("loan", nextLoan);
            return "approve-loan";  // This corresponds to approve-loan.html
        } else {
            model.addAttribute("message", "No pending loans.");
            return "no-loans";  // This corresponds to no-loans.html
        }
    }

    // Approve the loan
    @PostMapping("/approve/{loanId}")
    public String approveLoan(@PathVariable int loanId) {
        loanService.approveLoan(loanId);
        return "redirect:/admin/loans";  // Redirect to show the next loan after approval
    }
}
