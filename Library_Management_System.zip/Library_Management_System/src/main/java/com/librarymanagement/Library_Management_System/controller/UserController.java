package com.librarymanagement.Library_Management_System.controller;

import com.librarymanagement.Library_Management_System.entity.User;
import com.librarymanagement.Library_Management_System.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

import java.util.List;

@Controller
@RequestMapping("/")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    // Display the signup form
    @GetMapping("/signup")
    public String showSignupForm() {
        return "signup"; // This should match the name of your HTML file
    }

    // Handle signup form submission
    @PostMapping("/signup")
    public String registerUser(@RequestParam String name,
                               @RequestParam String email,
                               @RequestParam String password,
                               @RequestParam String userType,
                               Model model,
                               HttpServletResponse response) {
        try {
            User newUser = new User(name, email, userType, password);
            User savedUser = userService.addUser(newUser);

            if (savedUser != null) {
                // Add the user ID to cookies
                Cookie userIdCookie = new Cookie("userId", String.valueOf(savedUser.getUserId()));
                userIdCookie.setHttpOnly(true);
                userIdCookie.setPath("/");
                response.addCookie(userIdCookie);

                // Check the user type and redirect accordingly
                if ("admin".equalsIgnoreCase(userType)) {
                    // Redirect to the admin books page if the user is an admin
                    model.addAttribute("message", "Admin registration successful!");
                    logger.info("Admin registration successful for: {}", name);
                    return "redirect:/adminbooks"; // Redirect to the admin books page
                } else {
                    // Redirect to the books page for regular users
                    model.addAttribute("message", "Registration successful!");
                    logger.info("User registration successful for: {}", name);
                    return "redirect:/books"; // Redirect to the books page for regular users
                }
            } else {
                model.addAttribute("error", "User could not be saved.");
                logger.error("User registration failed for: {}", name);
            }

            return "signup"; // Stay on the signup page if registration fails
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred during registration: " + e.getMessage());
            logger.error("An error occurred during user registration: {}", e.getMessage(), e);
            return "signup"; // Stay on the signup page in case of error
        }
    }


    // Display the login form
    @GetMapping("/login")
    public String showLoginForm() {
        return "login"; // Return the login page
    }

    // Handle login form submission
    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            Model model,
                            HttpServletResponse response) {
        try {
            // Validate the user's email and password
            User user = userService.findByEmail(email);

            if (user != null && user.getPassword().equals(password)) {
                // Add the user ID to cookies
                Cookie userIdCookie = new Cookie("userId", String.valueOf(user.getUserId()));
                userIdCookie.setHttpOnly(true);
                userIdCookie.setPath("/");
                response.addCookie(userIdCookie);

                // Check the user type
                if ("admin".equalsIgnoreCase(user.getUserType())) {
                    // Redirect to the admin books page if the user is an admin
                    model.addAttribute("message", "Admin login successful!");
                    logger.info("Admin login successful for: {}", email);
                    return "redirect:/adminbooks"; // Redirect to the admin books page
                } else {
                    // Redirect to the books page for regular users
                    model.addAttribute("message", "Login successful!");
                    logger.info("User login successful for: {}", email);
                    return "redirect:/books"; // Redirect to the books page for regular users
                }
            } else {
                model.addAttribute("error", "Invalid email or password.");
                logger.error("Login failed for: {}", email);
                return "login"; // Stay on the login page if login fails
            }
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred during login: " + e.getMessage());
            logger.error("An error occurred during user login: {}", e.getMessage(), e);
            return "login"; // Stay on the login page in case of error
        }
    }


    // Display all users (you can remove this method if it's not needed)
    @GetMapping("/users")
    public String showAllUsers(Model model) {
        try {
            List<User> users = userService.getAllUsers(); // Fetch all users
            model.addAttribute("users", users);
            return "users"; // Return the users page
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while fetching users: " + e.getMessage());
            logger.error("An error occurred while fetching users: {}", e.getMessage(), e);
            return "error"; // Return an error page in case of failure
        }
    }
}
