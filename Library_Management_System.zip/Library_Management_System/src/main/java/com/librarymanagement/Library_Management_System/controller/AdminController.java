package com.librarymanagement.Library_Management_System.controller;

import com.librarymanagement.Library_Management_System.entity.Book;
import com.librarymanagement.Library_Management_System.entity.Loan;
import com.librarymanagement.Library_Management_System.service.BookService;
import com.librarymanagement.Library_Management_System.service.CategoryService;
import com.librarymanagement.Library_Management_System.service.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/adminbooks")
public class AdminController {

    @Autowired
    private BookService bookService;
    @Autowired
    private LoanService loanService;
    @Autowired
    private CategoryService categoryService;

    // Display all books
    @GetMapping
    public String showAllBooks(Model model) {
        try {
            model.addAttribute("books", bookService.getAllBooks());  // Fetch all books
            return "adminbooks";  // Return the books page
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while fetching books: " + e.getMessage());
            return "error"; // Return an error page in case of failure
        }
    }

    @PostMapping("/update-availability/{bookId}/{availability}")
    public String updateBookAvailability(@PathVariable("bookId") int bookId,
                                         @PathVariable("availability") int availability) {
        try {
            Book book = bookService.getBookById(bookId);
            if (book != null) {
                book.setAvailability(availability);
                bookService.saveBook(book);  // Save the updated book
                return "redirect:/adminbooks";  // Redirect back to the books page
            } else {
                return "error";  // If the book is not found
            }
        } catch (Exception e) {
            return "error";  // Show an error page in case of an issue
        }
    }

    @PostMapping("/delete/{bookId}")
    public String deleteBook(@PathVariable("bookId") int bookId) {
        try {
            System.out.println("Deleting book with ID: " + bookId);
            bookService.deleteBookById(bookId);  // Delete the book from the database
            return "redirect:/adminbooks";  // Redirect back to the books page
        } catch (Exception e) {
            e.printStackTrace();  // Log the error
            return "error";  // Show an error page if something goes wrong
        }
    }
    // Display the Add Book Form
    @GetMapping("/add")
    public String showAddBookForm(Model model) {
        model.addAttribute("categories", categoryService.getAllCategories());  // Add categories to the model
        return "add-book";  // Return the add-book form view
    }

    // Handle the Add Book Form Submission
    @PostMapping("/add")
    public String addBook(@ModelAttribute Book book, Model model) {
        try {
            bookService.saveBook(book);  // Save the new book
            model.addAttribute("message", "Book added successfully!");  // Success message
            return "redirect:/adminbooks";  // Redirect back to the list of books
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while adding the book: " + e.getMessage());  // Error message
            return "add-book";  // Stay on the Add Book form in case of an error
        }
    }

}

