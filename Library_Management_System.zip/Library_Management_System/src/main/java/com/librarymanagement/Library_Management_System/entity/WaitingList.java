package com.librarymanagement.Library_Management_System.entity;

import com.librarymanagement.Library_Management_System.util.QueueUtil;

public class WaitingList {
    private int bookId;
    private QueueUtil<Integer> userQueue; // QueueUtil to manage user IDs in the waiting list

    // Constructor
    public WaitingList(int bookId) {
        this.bookId = bookId;
        this.userQueue = new QueueUtil<>();
    }

    // Add user to the waiting list using QueueUtil's enqueue method
    public void addUserToWaitingList(int userId) {
        userQueue.enqueue(userId);
    }

    // Remove and get the next user in the waiting list using QueueUtil's dequeue method
    public int getNextUser() {
        return userQueue.dequeue();
    }

    // Check if the waiting list is empty using QueueUtil's isEmpty method
    public boolean isEmpty() {
        return userQueue.isEmpty();
    }

    // Get the current size of the waiting list using QueueUtil's size method
    public int size() {
        return userQueue.size();
    }

    // Getters and Setters
    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }
}
