package com.librarymanagement.Library_Management_System.service;

import com.librarymanagement.Library_Management_System.entity.Book;
import com.librarymanagement.Library_Management_System.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    // Get all books
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    // Get book details by ID
    public Book getBookById(int bookId) {
        Optional<Book> book = bookRepository.findById(bookId);
        return book.orElse(null); // Return null if the book is not found
    }
    // Fetch books by category names
    public List<Book> getBooksByCategoryNames(List<String> categoryNames) {
        return bookRepository.findByCategoryIn(categoryNames);
    }
    // Save a new book or update an existing one
    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    // Delete a book by ID
    public void deleteBookById(int bookId) {
        Optional<Book> book = bookRepository.findById(bookId);
        if (book.isPresent()) {
            bookRepository.deleteById(bookId);
        }
    }

}
