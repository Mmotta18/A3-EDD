package com.librarymanagement.Library_Management_System.controller;

import com.librarymanagement.Library_Management_System.entity.Loan;
import com.librarymanagement.Library_Management_System.service.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class LoanController {

    @Autowired
    private LoanService loanService;

    // Display loan history for a user
    @GetMapping("/loan-history/{userId}")
    public String getLoanHistory(@PathVariable("userId") int userId, Model model) {
        List<Loan> loans = loanService.getLoanHistoryByUserId(userId);
        model.addAttribute("userId", userId);
        model.addAttribute("loans", loans);
        return "loan-history";  // Render the loan history page
    }

    // Handle book return request
    @PostMapping("/return-book/{loanId}")
    public String returnBook(@PathVariable("loanId") int loanId, Model model) {
        try {
            // Get the loan by its ID
            Loan loan = loanService.getLoanById(loanId);
            int userId = loan.getUserId();  // Get the userId from the loan object

            // Delete the loan entry from the database
            loanService.deleteLoanById(loanId);

            // Add success message
            model.addAttribute("message", "Book returned successfully.");

            // Redirect to the user's loan history page, passing the userId in the URL
            return "redirect:/loan-history/" + userId;  // Redirect with the userId in the URL
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while returning the book: " + e.getMessage());
            return "loan-history";  // Stay on the loan history page and display error
        }
    }
    // Handle book loan request
    @PostMapping("/request-loan")
    public String requestLoan(@RequestParam("bookId") int bookId, HttpServletRequest request, Model model) {
        try {
            // Retrieve the userId from cookies
            Cookie[] cookies = request.getCookies();
            int userId = -1;
            for (Cookie cookie : cookies) {
                if ("userId".equals(cookie.getName())) {
                    userId = Integer.parseInt(cookie.getValue());
                    break;
                }
            }

            if (userId == -1) {
                model.addAttribute("error", "User ID is not available in cookies.");
                return "error";  // Show an error page if userId is not found
            }

            // Call the service to request a loan for the book
            loanService.requestLoan(bookId, userId);
            model.addAttribute("message", "Loan request successful.");
            return "redirect:/loan-history/" + userId;  // Redirect to loan history after successful request
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while requesting the loan: " + e.getMessage());
            return "error";  // Show an error page if loan request fails
        }
    }
}
