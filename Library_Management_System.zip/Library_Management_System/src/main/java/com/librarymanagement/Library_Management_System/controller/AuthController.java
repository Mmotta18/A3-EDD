package com.librarymanagement.Library_Management_System.controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @GetMapping("/logout")
    public String logout(HttpServletResponse response) {
        // Remove the userId cookie by setting its max age to 0
        Cookie userIdCookie = new Cookie("userId", "");
        userIdCookie.setMaxAge(0);
        userIdCookie.setPath("/");  // Make cookie available for the entire domain
        response.addCookie(userIdCookie);

        return "redirect:/";  // Redirect to the home page after logout
    }
}
