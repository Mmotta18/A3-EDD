package com.librarymanagement.Library_Management_System.controller;

import com.librarymanagement.Library_Management_System.entity.Category;
import com.librarymanagement.Library_Management_System.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/admin/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    // Display the form to add a new category
    @GetMapping("/add")
    public String showAddCategoryForm(Model model) {
        // Fetch all categories to populate the parent category dropdown
        model.addAttribute("categories", categoryService.getAllCategories()); // Fetch all categories
        model.addAttribute("category", new Category()); // Add empty category for form binding
        return "add-category"; // The view name for the form
    }

    // Handle form submission to add a new category
    @PostMapping("/add")
    public String addCategory(Category category, Model model) {
        try {
            categoryService.saveCategory(category); // Save the new category to the database
            model.addAttribute("message", "Category added successfully!");
            return "redirect:/admin/categories/add"; // Redirect back to the form
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred while adding the category.");
            return "add-category"; // Stay on the form if there is an error
        }
    }
}
